// Nighttime Vacuum
// Le robot se promène dans son environnement et réagit différemment si
// une moustache, l'autre moustache ou les deux moustaches sont enfoncées
// ... mais seulement s'il fait sombre. S'il fait clair, le robot est
// immobile.
// 
// Code original : https://www.cs2n.org/u/mp/badge_pages/1748
// Code adapté ici : https://physcrowley.github.io/Robotique/p7-4m_act2.html
//

#include <Arduino.h>
#include <RobotDrive.h> // notre bibliothèque pour l'entraînement différentiel

/*
DÉFINIR LES CONNEXIONS MATÉRIELLES
*/

// La broche de l'haut-parleur

const int speakerPort = 4;

// Les broches pour les moustaches

const int rightWhisker = 7;
const int leftWhisker = 5;
const int pressed = LOW;
const int released = HIGH;

// la broche du phototransistor

const int photoSensor = A3;

/*
Déclarations avancées de fonctions sur mesure
*/

// vide en ce moment

/*
Fonctions du sketch Arduino
*/

// initialiser le matériel et les connexions
void setup() {
  pinMode(rightWhisker, INPUT); // initialiser le mode des moustaches
  pinMode(leftWhisker, INPUT);

  setRobotDrivePins(10, 11); // initialiser les broches des roues

  Serial.begin(9600); // pour le débogagge (communication des valeurs)

  tone(speakerPort, 2000, 1000); // un ton de 2000Hz pendant 1s
  delay(1000); // attendre la fin du ton
}

// code à répéter infiniment
void loop() {

  // Lire le capteur de lumière
  unsigned int lightLevel = analogRead(photoSensor);

  Serial.println(lightLevel); // afficher la valeur au moniteur de série

  if (lightLevel < 50) {
    // il fait assez sombre pour se déplacer

    // ...alors vérifie s'il y a des obstacles
    bool rightState = digitalRead(rightWhisker);
    bool leftState = digitalRead(leftWhisker);

    // recule s'il y a contact avec un obstacle
    if (leftState == pressed && rightState == pressed) {
      backward();
      delay(1000); // ça donne combien de cm, environ?
      turnLeft();
      delay(800); // environ 120 degrés (plus que 90 degrés)
    } else if (leftState == pressed) {
      backward();
      delay(1000);
      turnRight();
      delay(400); // environ 60 degrées (moins que 90 degrés)
    } else if (rightState == pressed) {
      backward();
      delay(1000);
      turnLeft();
      delay(400); // environ 60 degrées (moins que 90 degrés)
    } else {
      // ... sinon avance
      forward();
    }

  } else {
    // il fait trop clair pour se déplacer

    // alors on s'immobilise
    stop();
  }

}

/*
Définition des fonctions sur mesure
*/

// vide en ce moment
