// Phototransistor Demo + Light Level Pitch
//
// Code de démarrage pour voir les valeurs produites par le phototransitor
// et aussi, dans un deuxième temps, en remplaçant le code par celui dans
// le fichier light_level.bak :
// Code qui ajuste la fréquence du ton émis par le haut-parleur en fonction
// de la valeur du phototransistor 
// 
// Code original : https://www.cs2n.org/u/mp/badge_pages/162
// Code adapté ici : https://physcrowley.github.io/Robotique/p7-4m_act2.html
//

#include <Arduino.h>

/*
DÉFINIR LES CONNEXIONS MATÉRIELLES
*/

const int photoSensor = A3;


// initialiser le matériel et les connexions
void setup() {
  Serial.begin(9600);
}


// code à répéter infiniment
void loop() {
  Serial.println(analogRead(photoSensor));
}
