// Whisker Setup
//
// Tester que les moustaches fonctionnent correctement en avançant si
// la moustache n'est pas enfoncé.
// 
// Code original : https://www.cs2n.org/u/mp/badge_pages/1747
// Code adapté ici : https://physcrowley.github.io/Robotique/p7-4m_act2.html
//

/*
Cette version du programme remplace aussi les macros avec des variables et
l'utilisation directe des méthodes de Servo avec les fonctions que nous avons
définies dans la bibliothèque `RobotDrive`.

Par contre, une des macros était pour un appelle de méthode, `analogRead()`, alors 
on a dû remplacer le code directement dans la condition `if` à l'intérieur de 
loop() et y insérer la référence `whisker` au lieu du chiffre littérale 7 pour 
maintenir la lisibilité du code.
*/

#include <Arduino.h>
#include <RobotDrive.h>

// La broche de l'haut-parleur
const int speakerPort = 4;

const int whisker = 7; // la broche pour la moustache à tester
const int pressed = 0; // la valeur sur la broche quand il y a contact

// se lance une fois au début du programme
void setup() {
  pinMode(whisker, INPUT); // les capteurs sont des entrées à lire

  setRobotDrivePins(10, 11); // initialiser les broches des roues

  int toneLength = 1000; // 1 seconde = 1000ms
  tone(speakerPort, 2000, toneLength); // jouer un ton de 2000Hz
  delay(toneLength); // bloquer le programme le temps que le ton joue
}

// se répète infiniment une fois que setup() est terminé
void loop() {
  if (analogRead(whisker) == pressed) {
    stop();
  } else {
    forward();
  }
}
