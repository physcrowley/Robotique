#include <Arduino.h> // inclure la bibliothèque standard d'Arduino
#include <Servo.h> // inclure la bibliothèque Servo

// déclarer les objets Servo qui contrôlent les moteurs gauche et droite

Servo leftMotor;
Servo rightMotor;

// déclarer les fonctions qui sont définies après la fonction loop

void stop();
void forward();

/* code à lancer une seule fois avant la répétition du code dans loop */
void setup() {
  // indiquer les broches de l'Arduino connectées à chaque Servo
  leftMotor.attach(10);
  rightMotor.attach(11);

  forward(); // appel de la fonction pour faire avancer le robot
  delay(1000);
  stop(); // appel de la fonction pour arrêter les roues du robot
}

/* code à répéter infiniment */
void loop() {
  // vide pour ce test
}

/* signaux aux moteur pour l'arrêt */
void stop() {
  leftMotor.writeMicroseconds(1500); // signal pour l'arrête
  rightMotor.writeMicroseconds(1500);
}

/* signaux aux moteurs pour avancer */
void forward() {
  leftMotor.writeMicroseconds(1700); // signal pour rotation antihoraire
  rightMotor.writeMicroseconds(1300); // signal pour rotation horaire
}