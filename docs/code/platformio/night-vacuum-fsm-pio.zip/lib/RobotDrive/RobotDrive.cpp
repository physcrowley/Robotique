#include <Servo.h> // inclure la bibliothèque pour les Servo
#include <RobotDrive.h> // inclure notre bibliothèque

Servo leftMotor;
Servo rightMotor;

void setRobotDrivePins(int leftPin, int rightPin) {
    leftMotor.attach(leftPin);
    rightMotor.attach(rightPin);
}

void stop() {
    leftMotor.writeMicroseconds(1500);
    rightMotor.writeMicroseconds(1500);
}

void forward() {
    leftMotor.writeMicroseconds(1700);
    rightMotor.writeMicroseconds(1300);
}

void backward() {
    leftMotor.writeMicroseconds(1300);
    rightMotor.writeMicroseconds(1700);
}

void turnLeft() {
    leftMotor.writeMicroseconds(1300);
    rightMotor.writeMicroseconds(1300);
}

void turnRight() {
    leftMotor.writeMicroseconds(1700);
    rightMotor.writeMicroseconds(1700);
}