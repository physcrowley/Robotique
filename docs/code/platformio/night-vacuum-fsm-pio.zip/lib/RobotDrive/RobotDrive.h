#ifndef RobotDrive_h
#define RobotDrive_h

void setRobotDrivePins(int leftPin, int rightPin);
void stop();
void forward();
void backward();
void turnLeft();
void turnRight();

#endif
