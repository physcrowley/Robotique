// Nighttime Vacuum - FSM VERSION
//
// Le robot se promène dans son environnement et réagit différemment si
// une moustache, l'autre moustache ou les deux moustaches sont enfoncées
// ... mais seulement s'il fait sombre. S'il fait clair, le robot est
// immobile.
// 
// Code original : https://www.cs2n.org/u/mp/badge_pages/1748
// Code adapté ici : https://physcrowley.github.io/Robotique/p7-4m_act2.html
//

#include <Arduino.h>
#include <RobotDrive.h> // notre bibliothèque pour l'entraînement différentiel

/*
DÉFINIR LES CONNEXIONS MATÉRIELLES
*/

// La broche de l'haut-parleur

const int speakerPort = 4;

// Les broches pour les moustaches

const int rightWhisker = 7;
const int leftWhisker = 5;
const int pressed = LOW;
const int released = HIGH;

// la broche du phototransistor

const int photoSensor = A3;

/*
Définir les états de la machine à états finis
*/

enum class States {
  SETUP,
  IDLE,
  ADVANCE,
  AVOID_FRONT,
  AVOID_RIGHT,
  AVOID_LEFT
};

States currentState = States::SETUP;
unsigned long start; // référence de temps

/*
Déclarations avancées de fonctions sur mesure
*/

bool dark();
void advance();
void avoidFront();
void avoidLeft();
void avoidRight();

/*
Fonctions du sketch Arduino
*/


// initialiser le matériel et les connexions
void setup() {
  pinMode(rightWhisker, INPUT); // initialiser le mode des moustaches
  pinMode(leftWhisker, INPUT);

  setRobotDrivePins(10, 11); // initialiser les broches des roues

  Serial.begin(9600); // pour le débogagge (communication des valeurs)

  tone(speakerPort, 2000, 1000); // un ton de 2000Hz pendant 1s
  delay(1000); // attendre la fin du ton
}


// code à répéter infiniment
void loop() {
  switch (currentState) {
  case States::SETUP:
    currentState = States::IDLE;
    break;
  case States::IDLE:
    stop();
    if (dark()) {
      currentState = States::ADVANCE;
    }
    break;
  case States::ADVANCE:
    advance();
    break;
  case States::AVOID_FRONT:
    avoidFront();
    break;
  case States::AVOID_LEFT:
    avoidLeft();
    break;
  case States::AVOID_RIGHT:
    avoidRight();
    break;
  }
}


/*
Définition des fonctions sur mesure
*/


bool dark() {
  return analogRead(photoSensor) < 50;
}


void advance() {
  if (!dark()) {
    currentState = States::IDLE; // transition liée au capteur
    return;
  }

  forward();

  bool rightState = digitalRead(rightWhisker);
  bool leftState = digitalRead(leftWhisker);

  if (leftState == pressed || rightState == pressed) {
    start = millis(); // référence de temps pour le contact
  }

  if (leftState == pressed && rightState == pressed) {
    currentState = States::AVOID_FRONT;
  } else if (leftState == pressed) {
    currentState = States::AVOID_LEFT;
  } else if (rightState == pressed) {
    currentState = States::AVOID_RIGHT;
  }
}


void avoidFront() {
  static const int reverseDelay = 1000;
  static const int turnDelay = 800;

  if (!dark()) {
    currentState = States::IDLE; // transition liée au capteur
    return;
  }

  if (millis() - start < reverseDelay) {
    backward();
  } else if (millis() - start < reverseDelay + turnDelay) {
    turnLeft();
  } else {
    currentState = States::ADVANCE; // transition liée au délais
  }
}


void avoidLeft() {
  static const int reverseDelay = 1000;
  static const int turnDelay = 400;

  if (!dark()) {
    currentState = States::IDLE; // transition liée au capteur
    return;
  }

  if (millis() - start < reverseDelay) {
    backward();
  } else if (millis() - start < reverseDelay + turnDelay) {
    turnRight();
  } else {
    currentState = States::ADVANCE; // transition liée au délais
  }
}


void avoidRight() {
  static const int reverseDelay = 1000;
  static const int turnDelay = 400;

  if (!dark()) {
    currentState = States::IDLE; // transition liée au capteur
    return;
  }

  if (millis() - start < reverseDelay) {
    backward();
  } else if (millis() - start < reverseDelay + turnDelay) {
    turnLeft();
  } else {
    currentState = States::ADVANCE; // transition liée au délais
  }
}
