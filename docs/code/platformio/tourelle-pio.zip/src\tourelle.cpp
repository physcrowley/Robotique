#include <Arduino.h>
#include <Servo.h>

Servo lower;
Servo upper;

const u8 lowerPin = 11;
const u8 upperPin = 9;
const u8 lowerPotPin = A2;
const u8 upperPotPin = A4;

void setup() {
  // déclarer l'usage des broches
  pinMode(lowerPin, OUTPUT);
  pinMode(upperPin, OUTPUT);
  pinMode(lowerPotPin, INPUT);
  pinMode(upperPotPin, INPUT);

  // initialiser les servomoteurs
  lower.attach(lowerPin);
  upper.attach(upperPin);
  
  // pour le déboggage
  Serial.begin(9600);
}

void loop() {
  // lire les valeurs sur les potentiomètres
  

  // mapper les valeurs minimales et maximales du potentiomètre aux valeurs minimales
  // et maximales des servomoteurs



  // contrôler les positions des servomoteurs


}
