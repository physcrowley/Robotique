#include <Arduino.h> // inclure la bibliothèque standard d'Arduino
#include <Servo.h> // inclure la bibliothèque Servo

Servo leftMotor; // déclarer un objet Servo qui contrôle le moteur gauche

/* code à lancer une seule fois avant la répétition du code dans loop */
void setup() {

    leftMotor.attach(10); // ce Servo est contrôlé par la broche 10

    // envoyé un signal comportant des pulsations de 1700 microsecondes
    // (pleine vitesse rotation antihoraire)
    leftMotor.writeMicroseconds(1700);

    delay(1000); // attendre 1000ms avant la prochaine instruction

    // enoyé un signal comportant des pulsations de 1500 microsecondes
    // (arrêt complet)
    leftMotor.writeMicroseconds(1500);
}

/* code à répéter infiniment */
void loop() {
    // vide pour ce test
}