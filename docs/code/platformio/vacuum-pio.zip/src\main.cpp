// Vacuum Pseudocoding Start
//
// Navigation du robot avec les moustaches tactiles.
// Le robot joue un ton différent selon si les deux moustaches
// sont enfoncées, une est enfoncée ou aucune n'est enfoncée.
// 
// Code original : https://www.cs2n.org/u/mp/badge_pages/1747
// Code adapté ici : https://physcrowley.github.io/Robotique/p7-4m_act2.html
//

/*
Cette version du programme remplace les macros avec des variables.

Par contre, les macros pour l'appel de la méthode `digitalRead()` on été
remplacés par la déclaration des variables `leftState` et `rightState` dans
loop(). Ces variables sont de type `bool` ou booléen. Ce type de donnée en C++
peut seulement stocké un 1 ou un 0 (`true` ou `false`; `HIGH` ou `LOW`). On
assigne à ces variables le résultat d'un appel à digitalRead().
*/

#include <Arduino.h>

// La broche de l'haut-parleur
const int speakerPort = 4;

// Les broches pour les moustaches
const int rightWhisker = 7;
const int leftWhisker = 5;

// Les états numériques possibles des moustaches (avec digitalRead)
const int pressed = LOW;
const int released = HIGH;

// se lance une fois au début du programme
void setup() {
  // les capteurs sont des entrées à lire
  pinMode(rightWhisker, INPUT);
  pinMode(leftWhisker, INPUT);

  // jouer un ton pour signaler la fin de setup
  int toneLength = 1000;
  tone(speakerPort, 2000, toneLength);
  delay(toneLength);
}

// se répète infiniment une fois que setup() est terminé
void loop() {
  // lire l'état des capteurs; 
  // on utilise bool qui contient juste true ou false (0 ou 1; LOW ou HIGH)
  bool leftState = digitalRead(leftWhisker);
  bool rightState = digitalRead(rightWhisker);

  // Série de conditions pour les états possibles
  if (leftState == pressed && rightState == pressed) {
    tone(speakerPort, 2000); // ton pour un double contact
  } else {
    if (leftState == pressed) {
      tone(speakerPort, 1000); // ton pour un contact seulement à gauche
    } else {
      if (rightState == pressed) {
        tone(speakerPort, 500); // ton pour un contact seulement à droite
      } else {
        noTone(speakerPort); // absence de ton si aucun contact
      }
    }
  }
}
