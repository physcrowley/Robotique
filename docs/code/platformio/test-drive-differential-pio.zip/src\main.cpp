#include <Arduino.h> // inclure la bibliothèque standard d'Arduino
#include <Servo.h> // inclure la bibliothèque Servo

// déclarer les objets Servo qui contrôlent les moteurs gauche et droite

Servo leftMotor; 
Servo rightMotor;

/* code à lancer une seule fois avant la répétition du code dans loop */
void setup() {
  // indiquer les broches de l'Arduino connectés à chaque Servo
  leftMotor.attach(10);
  rightMotor.attach(11);

  // signal en pulsations de la durée spécifiée : 
  // 1300 -> horaire; 1500 -> arrêt; 1700 -> antihoraire
  leftMotor.writeMicroseconds(1700);
  rightMotor.writeMicroseconds(1700);
  
  delay(1000); // attendre 1000ms avant la prochaine instruction

  // signal pour l'arrêt complet
  leftMotor.writeMicroseconds(1500);
  rightMotor.writeMicroseconds(1500);
}

/* code à répéter infiniment */
void loop() {
  // vide pour ce test
}