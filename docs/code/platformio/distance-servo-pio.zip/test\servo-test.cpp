/*
Ce programme vous aide à vérifier indépendamment le comportement de chaque servomoteur avant de
l'intégrer dans un projet.

Chaque fois que vous utilisez un nouveau servomoteur, vous devrez :
  1) lire les spécifications pour le servo (faire une recherche en ligne ou auprès du fournisseur)
  2) et tester le servo

Cela élimine les incertitudes concernant le contrôle du servo. S'il y a des problèmes
après ces tests, on peut savoir que c'est causé par quelque chose d'autre (connexions
électriques, source d'énergie ou logique du programme)
*/

#include <Arduino.h>
#include <Servo.h>
#include <unity.h>

Servo motor;
const int motorPin = 5;

/*
SIGNAUX POUR LES SERVOMOTEURS
À vérifier/modifier durant les tests de calibrage
*/
const int CENTER_OR_STOP = 1500; // microsecondes et fixe -> calibrez le servomoteur au besoin
const int CLOCKWISE_LIMIT = 500; // microsecondes -> à vérifier durant les tests
const int COUNTERCLOCKWISE_LIMIT = 2500; // microsecondes -> à vérifier durant les tests

/*
FONCTIONS PERSONNELLES POUR LES MOTEURS
Emballer les commandes moteur avec des noms plus descriptifs
*/

void clockWise() {
  motor.writeMicroseconds(CLOCKWISE_LIMIT);
}

void counterClockWise() {
  motor.writeMicroseconds(COUNTERCLOCKWISE_LIMIT);
}

void centerOrStop() {
  motor.writeMicroseconds(CENTER_OR_STOP);
}


/*
FONCTIONS POUR LES TESTS
*/

// pour le framework Unity : à faire avant chaque test
void setUp() {}

// pour le framework Unity : à faire après chaque test
void tearDown() {}


void test_centerOrStop() {
  centerOrStop();
  delay(5000);
}

void test_clockWise() {
  clockWise(); 
  delay(5000);
  centerOrStop();
}
  
void test_counterClockWise() {
  counterClockWise();
  delay(5000);
  centerOrStop(); // recentrer/arrêter le moteur à la fin
}

// lancer le test dans la fonction setup d'Arduino
void setup() {
  delay(2000); // donner du temps pour établir la connexion Serial
  motor.attach(motorPin); // initialiser l'objet Servo en spécifiant sa broche de signal
  UNITY_BEGIN();
  RUN_TEST(test_centerOrStop);
  RUN_TEST(test_clockWise);
  RUN_TEST(test_counterClockWise);
  UNITY_END();
}

void loop() {
  // pas utilisé 
}

