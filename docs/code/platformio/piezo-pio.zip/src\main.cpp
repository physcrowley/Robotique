// Démo du haut-parleur piezoélectrique
//
// Utilise le haut-parleur piezoélectrique pour jouer un ton durant setup() et
// des tons différents après chaque type de mouvement dans loop().
// 
// Code original sur : https://www.cs2n.org/u/mp/badge_pages/1745
// Code adapté sur : https://physcrowley.github.io/Robotique/acceuil4M.html
//


/*
Cette version du programme diffère du fichier `.ino` original de plusieurs façons
importantes, notamment en remplaçant certains éléments avec des éléments plus
cohérents avec ce que nous connaissons, incluant le français :

1 - Remplace les commandes Servo avec les fonctions de notre bibliothèque
RobotDrive (dans le dossier /lib). Par exemple, au lieu de  :

  leftMotor.writeMicroseconds(1500);
  leftMotor.writeMicroseconds(1500);

on voit plutôt :

  stop();

2 - Remplace les macros `#define` avec la déclaration d'une variable avec le
modificateur `const` pour indiquer que c'est une constante, une valeur qu'on
ne veut pas changer durant le programme.

3- Remplace la valeur littérale pour la durée du ton dans tone() avec une
variable parce qu'on utilise aussi cette même valeur dans delay() immédiatement
après.
*/

#include <Arduino.h>
#include <RobotDrive.h> 

// La broche de l'haut-parleur
const int speakerPort = 4;

// se lance une fois au début du programme
void setup() {
  setRobotDrivePins(10, 11); // gauche = 10, droite = 11

  int toneLength = 1000; // 1 seconde = 1000ms
  tone(speakerPort, 2000, toneLength); // jouer un ton de 2000Hz
  delay(toneLength); // bloquer le programme le temps que le ton joue
}

// se répète infiniment une fois que setup() est terminé
void loop() {
  static const int toneLength = 1000;
  // `static` indique que toneLength sera déclaré 1 seule fois au lieu
  // de chaque fois que loop() se répète

  // avance pendant 1 seconde et joue un ton de 500Hz
  forward();
  delay(1000);
  stop();
  tone(speakerPort, 500, toneLength);
  delay(toneLength);

  // tourne vers la droite pendant 0.4 secondes et joue un ton de 1500Hz
  turnRight();
  delay(400);
  stop();
  tone(speakerPort, 1500, toneLength);
  delay(toneLength);
}
